package com.daniel.springsecurity.service;

import java.util.List;

import com.daniel.springsecurity.model.extra.Friend;

public interface FriendService {

	public void addFriend(Friend f);
	public List<Friend> listFriends();
	public Friend getFriendById(int id);
	public void removeFriend(int id);
	
}