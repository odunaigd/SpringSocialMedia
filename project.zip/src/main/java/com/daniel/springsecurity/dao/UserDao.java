package com.daniel.springsecurity.dao;

import java.util.List;

import com.daniel.springsecurity.model.User;

public interface UserDao {

	User findById(int id);
	
	User findByUsername(String username);
	
    void saveUser(User user);
    
    void deleteUserByUsername(String username);
     
    List<User> findAllUsers();
	
}

