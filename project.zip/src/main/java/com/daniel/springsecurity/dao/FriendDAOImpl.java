package com.daniel.springsecurity.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.stereotype.Repository;

import com.daniel.springsecurity.model.Friend;
import com.daniel.springsecurity.model.User;

@Repository("friendDao")
public class FriendDAOImpl extends AbstractDao<Integer, Friend> implements FriendDAO {

	@Override
	public void addFriend(Friend f) {
		persist(f);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Friend> listFriends() {
		Criteria criteria = createEntityCriteria();
        return (List<Friend>) criteria.list();
	}

	@Override
	public Friend getFriendById(int id) {
		return getByKey(id);
	}

	@Override
	public void removeFriend(int id) {
		// TODO Auto-generated method stub
		
	}



	
	
}