package com.daniel.springsecurity.dao;

import java.util.List;

import org.hibernate.Criteria;

import org.springframework.stereotype.Repository;


import com.daniel.springsecurity.model.Post;


@Repository("postDao")
public class PostDAOImpl extends AbstractDao<Integer, Post> implements PostDAO {

	@Override
	public void removePost(int id) {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Post> listPosts() {
		Criteria criteria = createEntityCriteria();
        return (List<Post>) criteria.list();
	}

	@Override
	public Post getPostById(int id) {
		return getByKey(id);
	}

	@Override
	public void addPost(Post p) {
		persist(p);
		
	}

	

}