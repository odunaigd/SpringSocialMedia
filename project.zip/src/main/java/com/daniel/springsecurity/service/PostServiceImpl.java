package com.daniel.springsecurity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.daniel.springsecurity.dao.PostDAO;
import com.daniel.springsecurity.model.Post;

@Service
public class PostServiceImpl implements PostService {
	
	@Autowired
	private PostDAO postDAO;

	
	@Override
	@Transactional
	public void addPost(Post p) {
			postDAO.addPost(p);
	}


	@Override
	@Transactional
	public List<Post> listPosts() {
		return postDAO.listPosts();
	}

	@Override
	@Transactional
	public Post getPostById(int id) {
		return postDAO.getPostById(id);
	}

	@Override
	@Transactional
	public void removePost(int id) {
				postDAO.removePost(id);
	}

}
