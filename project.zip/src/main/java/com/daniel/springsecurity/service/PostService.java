package com.daniel.springsecurity.service;

import java.util.List;


import com.daniel.springsecurity.model.Post;

public interface PostService {

	public void addPost(Post p);
	public List<Post> listPosts();
	public Post getPostById(int id);
	public void removePost(int id);
}
