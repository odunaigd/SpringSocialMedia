package com.daniel.springsecurity.model;

import javax.persistence.*;


@Entity
@Table(name="friends")
public class Friend {

	@Id
	@Column(name="friend_id")
	private int friendId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userId", nullable = false)
	private int userId;
	
	
	public int getFriendId() {
		return friendId;
	}

	public void setFriendId(int friendId) {
		this.friendId = friendId;
	}

	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
}
